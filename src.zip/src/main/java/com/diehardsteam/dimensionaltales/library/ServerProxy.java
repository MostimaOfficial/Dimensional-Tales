package com.diehardsteam.dimensionaltales.library;

public class ServerProxy
{
    public void registerRenderInfo() {
    }
}
