package com.diehardsteam.dimensionaltales.library;

import net.minecraft.item.*;

public class ObsidiumSword extends ItemSword
{
    public ObsidiumSword(final Item.ToolMaterial p_i45356_1_) {
        super(p_i45356_1_);
    }
}
