package com.diehardsteam.dimensionaltales.library;

public class ClientProxy extends ServerProxy
{
    @Override
    public void registerRenderInfo() {
    }
}
