package com.diehardsteam.dimensionaltales.library;

public class DimensionRegistry
{
}
