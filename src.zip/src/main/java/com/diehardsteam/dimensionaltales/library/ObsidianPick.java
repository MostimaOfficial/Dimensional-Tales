package com.diehardsteam.dimensionaltales.library;

import net.minecraft.item.*;

public class ObsidianPick extends ItemPickaxe
{
    protected ObsidianPick(final Item.ToolMaterial p_i45347_1_) {
        super(p_i45347_1_);
    }
}
