package com.diehardsteam.dimensionaltales.entities;

import net.minecraft.entity.*;
import net.minecraft.entity.monster.*;
import net.minecraft.world.*;

public abstract class EntityTest extends EntityCreature implements IMob
{
    public EntityTest(final World p_i1602_1_) {
        super(p_i1602_1_);
    }
}
